
<tr>
        <td>{id}</td>
        <td>{name}</td>
        <td class="span2">{description}</td>
        <td>{main}</td>
        <td>{sub}</td>
        <td>{contact}</td>
        <td>{date}</td>
    <td><img src="/data/{pic}" title="{id}"/></td>
    <td class="span1"><a href="/admin/edit3/{id}">Edit</a></td>
    
</tr>