<!-- form to edit a menu item -->
<form action="/admin/post3/{id}" method="post">
    {fid}
    {fname}
    {fdescription}
    {fmain}
    {fsub}
    {fcontact}
    {fdate}
    {fpicture}
    {fsubmit}
</form>
