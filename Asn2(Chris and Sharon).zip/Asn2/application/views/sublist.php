<div class="header">
    <br />
    <h2>Categories: {main}</h2>
    <br />
</div>
{places}
<div class="row">
    
    <h3>{name}</h3>
    <div class="span5"><a href="{href}/{id}"><img src="/data/{pic}" title="{id}"/></a></div>
    <br />
    
</div>
{/places}