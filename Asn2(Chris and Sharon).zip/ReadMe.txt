Read Me

Christopher Lee and Sharon Wright

Completed the attractions model with the DB. 
Can edit attractions but not add/delete.
has at least 3 attractions for one main category.
There is a RDB with the attractions model.