{places}
<div class="header">
    <br />
    <h2>Category: {main_id}</h2>
    <br />
</div>
<div class="row">
    <div class="span11">
        <h3>{name}</h3>
    </div>
    <div class="span5"><a href="{href}"><img src="/data/{pic}" title="{name}"/></a></div>
    
    <div class="span7">
        <p class="lead">{description}</p><br/>
    </div>
    <div class="span11 offset1">
        <br />
        <p>---------------------------------------------------------------------------------------------------------------------------------------------------------------------</p>
        <br/>
    </div>
    
</div>
{/places}