<!-- form to edit a menu item -->
<form action="/admin/post3/{code}" method="post">
    {fcode}
    {fname}
    {fdescription}
    {fcategory}
    {fpicture}
    {fsubmit}
</form>
