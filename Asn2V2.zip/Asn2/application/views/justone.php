<div class="row">
    <div class="span3"><img src="/data/{mug}" title="{who}"/></div>
    <div class="span8 offset1">
        <p class="lead">{what}</p><br/>
        <p class="text-right">{who}</p>
    </div>
</div>