<div class="header">
    <br />
    <h2>{name}</h2>
    <br />
</div>
<div class="row">
    <br /><br/>
    <div class="span6"><img src="/data/{pic3}" title="{name}"/></div>
    <div class="span6"><img src="/data/{pic}" title="{name}"/><br /><br /></div>
    
    <div class="span6"><br /><br /><img src="/data/{pic2}" title="{name}"/><br /><br/><br /><br/></div>
    
    <div class="span12">
        <p class="lead">{description}</p><br/>
    </div>
    
</div>