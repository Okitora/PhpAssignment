<p class="lead">
    Our Menu List
</p>

<div class="row text-center">
    
    <table class="table">
        <tr>
            <th>Code</th>
            <th>Name</th>
            <th>Description</th>
            <th>Category</th>
            <th>Picture</th>
            <th>Edit</th>
        </tr>
        {themeat}
    </table>
</div>