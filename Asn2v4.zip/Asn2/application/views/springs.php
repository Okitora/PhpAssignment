<div class="header">
    <br />
    <h2>{name}</h2>
    <br />
</div>
<div class="row">
    <div class="span8">
         <br /><br/>
         <img src="/data/{pic}" title="{name}"/>
        <br /><br/><br /><br/>
    </div>
    <div class="span4">
        <p class="lead">{description}</p><br/>
    </div>
    
</div>