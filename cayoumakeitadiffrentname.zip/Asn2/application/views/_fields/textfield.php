<div class="control-group">
    <label class="control-label" for="{name}">{label}</label>
    <div class="controls">
        <input type="text" id="{name}" name="{name}" value="{value}" maxLength="{maxlen}" style="width:{size}em;height:2em" {disabled}/>
               <br/><small><em>{explain}</em></small>
    </div>
</div>
