<div class="row">
    
    <div class="span12">
       <h3>Christopher Lee and Sharon Wright Assignment 1</h3>
       <p class="lead">
           The design decision we decided to go with was to have a very clean look. 
           The background image is scenery in New Zealand; this was chosen,
           because many of the tourist attractions in New Zealand are of the beautiful 
           landscapes, such as Glaciers, Mountains, Caves, Beaches, etc.  
         <br />  
           The navigation 
           is at the top of each page for consistency throughout each page and is 
           in an easy to find place.  Some tourist websites can be somewhat tacky/flashy
           so the colors chosen here are to make everything flow and not standout.
       <br/>
       <br />
       The data structure can be a hashed list so the wanted attraction can be
           found easier.  Right now the category data is just dummy data.  But the
           categories can be sorted such as: natural/wildlife/scenery, food/restaurants,
           spas/resorts,  active activities, passive activities, etc.
       </p>
    
    </div>
</div>