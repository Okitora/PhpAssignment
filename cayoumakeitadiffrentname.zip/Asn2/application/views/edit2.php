
<tr>
    <td>{code}</td>
    <td>{name}</td>
    <td>{description}</td>
    <td>{category}</td>
    <td class="span1"><img src="/data/{pic}" title="{description}"/></td>
    <td class="span1"><a href="/admin/edit3/{code}">Edit</a></td>
    
</tr>