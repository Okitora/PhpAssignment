{places}
<div class="row">
    <div class="span11">
        <h2>{name}</h2>
    </div>
    <div class="span5"><img src="/data/{pic}" title="{name}"/></div>
    
    <div class="span7">
        <p>{description}</p><br/>
    </div>
 
</div>
{/places}