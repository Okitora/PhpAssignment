<div class="row">
    <div class="span13">
        <br /><br/>
        <img src="/data/{pic}" title="{name}"/>
        <br /><br /><br /><br/>
    </div>
    <div class="span12">
        <p class="lead">{description}</p>
    </div>
    
</div>